import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(LezzetTarifleriApp());
}

class LezzetTarifleriApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lezzet Tarifleri',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
        scaffoldBackgroundColor: Colors.grey[50],
      ),
      home: HomeScreen(),
    );
  }
}
