import '../models/recipe.dart';

class RecipeService {
  // Not using Firebase yet to avoid errors before setup
  // final FirebaseFirestore _db = FirebaseFirestore.instance;

  static List<Recipe> getMockRecipes() {
    return [
      Recipe(
        id: '1',
        title: 'Mercimek Çorbası',
        description: 'İçinizi ısıtacak geleneksel anne sıcaklığında lezzet.',
        imageUrl: 'https://cdn.yemek.com/mnresize/940/940/uploads/2014/06/mercimek-corbasi-yemekcom.jpg',
        ingredients: [
          '1 su bardağı kırmızı mercimek',
          '1 adet soğan',
          '1 adet havuç',
          '1 yemek kaşığı domates salçası',
          'Tuz, nane, pul biber',
          '6 su bardağı sıcak su'
        ],
        steps: [
          'Soğan ve havucu ince doğrayıp sıvı yağda kavurun.',
          'Salçayı ekleyip kokusu çıkana kadar kavurmaya devam edin.',
          'Yıkanmış mercimekleri ve baharatları ekleyin.',
          'Sıcak suyu ilave edip mercimekler yumuşayana kadar pişirin.',
          'Piştikten sonra pürüzsüz olması için blenderdan geçirin.',
        ],
      ),
      Recipe(
        id: '2',
        title: 'Karnıyarık',
        description: 'Patlıcan ve kıymanın fırında buluşan muhteşem uyumu.',
        imageUrl: 'https://cdn.yemek.com/mnresize/940/940/uploads/2022/08/karniyarik-yemekcom-2.jpg',
        ingredients: [
          '6 adet orta boy patlıcan',
          '250 gr kıyma',
          '2 adet soğan',
          '2 adet yeşil biber',
          '1 tatlı kaşığı salça',
          'Sıvı yağ, tuz, karabiber'
        ],
        steps: [
          'Patlıcanları alacalı soyup tuzlu suda bekletin ve hafifçe kızartın.',
          'İç harcı için soğanları ve kıymayı tavada kavurun.',
          'Doğranmış domates ve biberleri ekleyip ocaktan alın.',
          'Patlıcanların ortasını yararak açın ve iç harcı doldurun.',
          'Salçalı su ekleyip fırında 180 derecede 25 dakika pişirin.'
        ],
      ),
      Recipe(
        id: '3',
        title: 'Brownie',
        description: 'Yoğun çikolata keyfiyle çay saatlerinin vazgeçilmezi.',
        imageUrl: 'https://cdn.yemek.com/mnresize/940/940/uploads/2015/02/gercek-brownie-tarifi-1.jpg',
        ingredients: [
          '200 gr bitter çikolata',
          '150 gr tereyağı',
          '3 adet yumurta',
          '1 su bardağı şeker',
          '1 su bardağı un',
          '1 paket vanilya'
        ],
        steps: [
          'Tereyağı ve çikolatayı benmari usulü eritin.',
          'Yumurta ve şekeri krema kıvamına gelene kadar çırpın.',
          'İlk sıcaklığını atan çikolatalı karışımı yumurtalara yavaşça ekleyin.',
          'Un ve vanilyayı eleyerek dışarıdan içeri doğru spatula ile karıştırın.',
          'Önceden ısıtılmış 160 derece fırında içi hafif ıslak kalacak şekilde 25-30 dakika pişirin.'
        ],
      ),
    ];
  }
}
